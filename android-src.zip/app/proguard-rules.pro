# Scramble our own code (R8); keep only what the web page and Android must find by name.
-keepattributes *Annotation*
-keepclassmembers class * { @android.webkit.JavascriptInterface <methods>; }
-keep class info.quranicscience.app.MainActivity$Bridge { *; }
-keep class * extends android.app.Service
-keep class * extends android.content.BroadcastReceiver
-dontwarn javax.annotation.**
-dontwarn org.checkerframework.**
-renamesourcefileattribute SourceFile
-repackageclasses ''
