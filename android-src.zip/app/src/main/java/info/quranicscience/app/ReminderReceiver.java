package info.quranicscience.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;

/* Shows the "class starts in 1 hour" alert that the app scheduled on the phone. */
public class ReminderReceiver extends BroadcastReceiver {
    static final String CH = "classes";
    @Override public void onReceive(Context ctx, Intent in) {
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(CH) == null) {
            NotificationChannel c = new NotificationChannel(CH, "Class alerts", NotificationManager.IMPORTANCE_HIGH);
            c.setDescription("Alert 1 hour before each class"); nm.createNotificationChannel(c);
        }
        Intent open = new Intent(ctx, MainActivity.class); open.setAction(Intent.ACTION_VIEW); open.setData(Uri.parse("https://quranicscience.info/?app=1#learn")); open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(ctx, 7, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        String title = in.getStringExtra("title"); if (title == null) title = "Your class";
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(ctx, CH) : new Notification.Builder(ctx);
        b.setSmallIcon(R.drawable.ic_stat).setContentTitle("Class in 1 hour · ایک گھنٹے میں کلاس").setContentText(title)
         .setStyle(new Notification.BigTextStyle().bigText(title + "\nOpen the app and join on time. Please make wudu."))
         .setContentIntent(pi).setAutoCancel(true).setColor(0xFFC99A45);
        try { nm.notify(in.getIntExtra("nid", 1), b.build()); } catch (SecurityException e) {}
    }
}
