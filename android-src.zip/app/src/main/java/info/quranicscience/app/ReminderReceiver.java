package info.quranicscience.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;

/* Shows the "class starts in 1 hour" alert that the app scheduled on the phone. */
public class ReminderReceiver extends BroadcastReceiver {
    static final String CH = "v_class";
    @Override public void onReceive(Context ctx, Intent in) {
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        /* the server also sends this reminder by push; the phone's own alarm only speaks when there is no internet, so the voice never plays twice */
        try { android.net.ConnectivityManager cm = (android.net.ConnectivityManager) ctx.getSystemService(Context.CONNECTIVITY_SERVICE); android.net.NetworkInfo ni = cm == null ? null : cm.getActiveNetworkInfo();
            String fcm = ctx.getSharedPreferences("qs", Context.MODE_PRIVATE).getString("fcm", "");
            if (ni != null && ni.isConnected() && fcm != null && !fcm.isEmpty()) return; } catch (Exception e) {}
        VoiceAlerts.create(ctx);
        Intent open = new Intent(ctx, MainActivity.class); open.setAction(Intent.ACTION_VIEW); open.setData(Uri.parse("https://quranicscience.info/?app=1#learn")); open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(ctx, 7, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        String title = in.getStringExtra("title"); if (title == null) title = "Your class";
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(ctx, CH) : new Notification.Builder(ctx);
        if (Build.VERSION.SDK_INT < 26) b.setSound(Uri.parse("android.resource://" + ctx.getPackageName() + "/" + R.raw.v_class)).setPriority(Notification.PRIORITY_HIGH);
        b.setSmallIcon(R.drawable.ic_stat).setContentTitle("Class in 30 minutes · 30 منٹ میں کلاس").setContentText(title)
         .setStyle(new Notification.BigTextStyle().bigText(title + "\nOpen the app and join on time. Please make wudu."))
         .setContentIntent(pi).setAutoCancel(true).setColor(0xFFC99A45);
        try { nm.notify(in.getIntExtra("nid", 1), b.build()); } catch (SecurityException e) {}
    }
}
