package info.quranicscience.app;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/* Class recordings saved inside the app (private storage, one folder per course). Only this app can open them,
   and they play in the app's own secure player (no screenshots or screen recording). */
final class OfflineVideos {
    interface Progress { void on(String id, String state, int pct, String info); }
    static final ExecutorService POOL = Executors.newSingleThreadExecutor();
    static final Set<String> RUNNING = new HashSet<>();

    static String safe(String s) { return (s == null ? "x" : s).toLowerCase().replaceAll("[^a-z0-9_-]+", "-").replaceAll("^-+|-+$", ""); }
    static File root(Context c) { File d = new File(c.getFilesDir(), "offline"); d.mkdirs(); return d; }
    static File index(Context c) { return new File(root(c), "index.json"); }

    static synchronized JSONObject read(Context c) {
        try (InputStream in = new FileInputStream(index(c))) { byte[] b = new byte[(int) index(c).length()]; int n = 0; while (n < b.length) { int r = in.read(b, n, b.length - n); if (r < 0) break; n += r; }
            return new JSONObject(new String(b, 0, n, StandardCharsets.UTF_8)); } catch (Exception e) { return new JSONObject(); }
    }
    static synchronized void write(Context c, JSONObject o) {
        try (OutputStream out = new FileOutputStream(index(c))) { out.write(o.toString().getBytes(StandardCharsets.UTF_8)); } catch (Exception e) {}
    }
    static String list(Context c) {
        JSONObject o = read(c); JSONArray a = new JSONArray();
        try { java.util.Iterator<String> it = o.keys(); while (it.hasNext()) { String k = it.next(); JSONObject v = o.getJSONObject(k); if (new File(v.optString("path")).exists()) a.put(v); } } catch (Exception e) {}
        return a.toString();
    }
    static String path(Context c, String id) { JSONObject v = read(c).optJSONObject(id); return v == null ? null : v.optString("path", null); }
    static boolean delete(Context c, String id) {
        JSONObject o = read(c); JSONObject v = o.optJSONObject(id); if (v != null) new File(v.optString("path")).delete(); o.remove(id); write(c, o); return v != null;
    }
    static long usedBytes(Context c) { long t = 0; File[] ds = root(c).listFiles(); if (ds != null) for (File d : ds) { File[] fs = d.isDirectory() ? d.listFiles() : null; if (fs != null) for (File f : fs) t += f.length(); } return t; }

    /* meta: {id, course, courseName, title, url} */
    static void download(final Context c, final JSONObject meta, final Progress p) {
        final String id = meta.optString("id");
        synchronized (RUNNING) { if (id.isEmpty() || RUNNING.contains(id)) return; RUNNING.add(id); }
        p.on(id, "queued", 0, "");
        POOL.execute(() -> {
            File dir = new File(root(c), safe(meta.optString("course"))); dir.mkdirs();
            File part = new File(dir, safe(id) + ".part"), done = new File(dir, safe(id) + ".mp4");
            HttpURLConnection h = null;
            try {
                String u = meta.optString("url"); int hops = 0;
                while (true) {
                    h = (HttpURLConnection) new URL(u).openConnection(); h.setInstanceFollowRedirects(false);
                    h.setConnectTimeout(20000); h.setReadTimeout(60000); h.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) QSApp");
                    int code = h.getResponseCode();
                    if (code >= 300 && code < 400 && h.getHeaderField("Location") != null && hops++ < 8) { u = new URL(new URL(u), h.getHeaderField("Location")).toString(); h.disconnect(); continue; }
                    if (code != 200) throw new Exception("http " + code);
                    break;
                }
                String type = String.valueOf(h.getContentType());
                if (type.contains("text/html")) throw new Exception("not-public");
                long total = h.getContentLengthLong(), got = 0; int last = -1;
                try (InputStream in = h.getInputStream(); OutputStream out = new FileOutputStream(part)) {
                    byte[] buf = new byte[64 * 1024]; int r;
                    while ((r = in.read(buf)) > 0) { out.write(buf, 0, r); got += r;
                        int pct = total > 0 ? (int) (got * 100 / total) : -1;
                        if (pct != last) { last = pct; p.on(id, "progress", pct, String.valueOf(got)); } }
                }
                if (got < 50 * 1024) throw new Exception("too-small");
                if (done.exists()) done.delete(); part.renameTo(done);
                JSONObject o = read(c), v = new JSONObject(meta.toString()); v.put("path", done.getAbsolutePath()); v.put("size", done.length()); v.put("ts", System.currentTimeMillis()); v.remove("url");
                o.put(id, v); write(c, o);
                p.on(id, "done", 100, String.valueOf(done.length()));
            } catch (Exception e) { part.delete(); p.on(id, "error", 0, String.valueOf(e.getMessage())); }
            finally { if (h != null) h.disconnect(); synchronized (RUNNING) { RUNNING.remove(id); } }
        });
    }
}
