package info.quranicscience.app;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import java.util.Map;

/* Free app alerts from the Quranic Science automation (fee received, class open, certificate ready, teacher answered). */
public class PushService extends FirebaseMessagingService {
    @Override public void onNewToken(String token) { getSharedPreferences("qs", MODE_PRIVATE).edit().putString("fcm", token).apply(); }
    @Override public void onMessageReceived(RemoteMessage m) {
        Map<String, String> d = m.getData();
        String title = m.getNotification() != null ? m.getNotification().getTitle() : d.get("title");
        String body = m.getNotification() != null ? m.getNotification().getBody() : d.get("body");
        String url = d.get("url"); if (url == null || url.isEmpty()) url = "https://quranicscience.info/#learn";
        Intent open = new Intent(this, MainActivity.class); open.setAction(Intent.ACTION_VIEW); open.setData(Uri.parse(url)); open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, (int) (System.currentTimeMillis() & 0xffff), open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, "alerts") : new Notification.Builder(this);
        b.setSmallIcon(R.drawable.ic_stat).setContentTitle(title == null ? "Quranic Science" : title).setContentText(body == null ? "" : body)
         .setStyle(new Notification.BigTextStyle().bigText(body == null ? "" : body)).setContentIntent(pi).setAutoCancel(true).setColor(0xFFC99A45);
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        try { if (nm != null) nm.notify((int) (System.currentTimeMillis() & 0x7fffffff), b.build()); } catch (SecurityException e) {}
    }
}
