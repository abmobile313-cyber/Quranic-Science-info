package info.quranicscience.app;

import android.app.Activity;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.VideoView;
import java.io.File;

/* Plays a saved class recording from the app's private storage. Screenshots and screen recording are blocked. */
public class PlayerActivity extends Activity {
    VideoView v; int pos = 0;
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        FrameLayout f = new FrameLayout(this); f.setBackgroundColor(Color.BLACK);
        String path = getIntent().getStringExtra("path"), title = getIntent().getStringExtra("title");
        if (path == null || !new File(path).exists()) { TextView t = new TextView(this); t.setText("This video is not on the phone any more. Please download it again."); t.setTextColor(Color.WHITE); t.setGravity(Gravity.CENTER); f.addView(t); setContentView(f); return; }
        v = new VideoView(this);
        f.addView(v, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT, Gravity.CENTER));
        if (title != null) { TextView t = new TextView(this); t.setText(title); t.setTextColor(0xCCFFFFFF); t.setPadding(32, 32, 32, 32); f.addView(t, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.START)); }
        setContentView(f);
        MediaController mc = new MediaController(this); mc.setAnchorView(v); v.setMediaController(mc);
        v.setVideoURI(Uri.fromFile(new File(path)));
        if (b != null) pos = b.getInt("pos", 0);
        v.setOnPreparedListener(mp -> { if (pos > 0) v.seekTo(pos); v.start(); mc.show(3000); });
    }
    @Override protected void onSaveInstanceState(Bundle o) { super.onSaveInstanceState(o); if (v != null) o.putInt("pos", v.getCurrentPosition()); }
    @Override protected void onPause() { super.onPause(); if (v != null) { pos = v.getCurrentPosition(); v.pause(); } }
    @Override protected void onResume() { super.onResume(); if (v != null && pos > 0) v.seekTo(pos); }
}
