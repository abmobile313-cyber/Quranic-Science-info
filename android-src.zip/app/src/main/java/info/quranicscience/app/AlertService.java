package info.quranicscience.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.app.PendingIntent;
import java.util.ArrayDeque;

/* Loud alert voice (app 1.2.0): every alert plays  alarm tone -> voice -> course name  on the ALARM stream,
   one after another from a queue (never on top of each other), so other apps' notification sounds cannot cut it
   and it follows the alarm volume (raised to ~90% while speaking, then put back). */
public class AlertService extends Service {
    static final String CH_RUN = "qs_speaking";
    private static final ArrayDeque<int[]> Q = new ArrayDeque<>();
    private MediaPlayer mp; private boolean busy; private AudioManager am; private int oldVol = -1; private AudioFocusRequest afr;
    private PowerManager.WakeLock wl; private final Handler h = new Handler(Looper.getMainLooper());

    static void speak(Context ctx, String voiceCh, String course) {
        /* voice language chosen in the app (Me → Notification voice): ur (default), ar or en */
        String lg = ctx.getSharedPreferences("qs", Context.MODE_PRIVATE).getString("alang", "ur"), pre = "ar".equals(lg) ? "ar_" : "en".equals(lg) ? "en_" : "";
        String pkg = ctx.getPackageName(); android.content.res.Resources rs = ctx.getResources();
        String vn = (voiceCh == null || voiceCh.isEmpty()) ? "v_general" : voiceCh;
        int voice = rs.getIdentifier(pre + vn, "raw", pkg); if (voice == 0) voice = VoiceAlerts.raw(vn);
        int c = 0; course = shortOf(course);
        if (course != null && !course.isEmpty()) { String cn = "c_" + course.toLowerCase().replaceAll("[^a-z]", ""); c = rs.getIdentifier(pre + cn, "raw", pkg); if (c == 0) c = rs.getIdentifier(cn, "raw", pkg); }
        synchronized (Q) { Q.add(c != 0 ? new int[]{R.raw.a_alarm, voice, c} : new int[]{R.raw.a_alarm, voice}); }
        Intent i = new Intent(ctx, AlertService.class);
        try { if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i); else ctx.startService(i); } catch (Exception e) { /* background start refused: the silent notification still shows */ }
    }

    static String shortOf(String k) {
        if (k == null) return ""; k = k.replaceAll("-(full|live)$", "");
        switch (k) {
            case "all-in-one-creator-course": return "AIO"; case "tajweed-arabic-combo": return "TAC"; case "ai-masterclass": return "AIM";
            case "video-editing-course": return "VED"; case "ai-film-ads-video-editing": return "AFA"; case "aio-ai-film-combo": return "AIF";
            case "content-creation-zero-to-pro": return "CCP"; case "tajweed-class": return "TAJ"; case "arabic-speaking-class": return "ARB";
            case "ai-tajweed": return "AIT"; case "ai-arabic": return "AIA"; case "ai-tajweed-arabic-combo": case "ai-combo": return "AIC";
            case "ai-video-editing": return "AIV"; case "ai-content-creation": return "AICC"; case "ai-creator": return "AIX";
            default: return k.length() <= 5 ? k : "";
        }
    }
    static final String ACT_STOP = "info.quranicscience.app.STOP_ALERT";
    private long startedAt; private BroadcastReceiver scr;
    /* like an alarm: pressing the power button (or tapping Stop) silences all waiting alerts */
    private void stopAll() { synchronized (Q) { Q.clear(); } cur = null; if (mp != null) { try { mp.stop(); } catch (Exception e) {} mp.release(); mp = null; } busy = false; loudOff(); h.removeCallbacksAndMessages(null); if (wl != null && wl.isHeld()) wl.release(); stopForeground(true); stopSelf(); }
    private void watchPower() {
        if (scr != null) return;
        scr = new BroadcastReceiver() { @Override public void onReceive(Context c, Intent i) {
            String a = i.getAction(); if (!busy) return;
            if (Intent.ACTION_SCREEN_OFF.equals(a) || (Intent.ACTION_SCREEN_ON.equals(a) && System.currentTimeMillis() - startedAt > 2500)) stopAll(); } };
        IntentFilter f = new IntentFilter(); f.addAction(Intent.ACTION_SCREEN_OFF); f.addAction(Intent.ACTION_SCREEN_ON);
        try { if (Build.VERSION.SDK_INT >= 33) registerReceiver(scr, f, Context.RECEIVER_NOT_EXPORTED); else registerReceiver(scr, f); } catch (Exception e) { scr = null; }
    }
    @Override public int onStartCommand(Intent in, int f, int id) {
        if (in != null && ACT_STOP.equals(in.getAction())) { stopAll(); return START_NOT_STICKY; }
        watchPower();
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null && nm.getNotificationChannel(CH_RUN) == null) { NotificationChannel ch = new NotificationChannel(CH_RUN, "Speaking an alert", NotificationManager.IMPORTANCE_MIN); ch.setSound(null, null); nm.createNotificationChannel(ch); }
            PendingIntent stop = PendingIntent.getService(this, 43, new Intent(this, AlertService.class).setAction(ACT_STOP), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            Notification n = new Notification.Builder(this, CH_RUN).setSmallIcon(R.drawable.ic_stat).setContentTitle("Quranic Science 🔊").setContentText("Press the power button or tap Stop to silence").setColor(0xFFC99A45)
                .setContentIntent(stop).addAction(new Notification.Action.Builder(null, "⏹ Stop", stop).build()).build();
            try { if (Build.VERSION.SDK_INT >= 29) startForeground(42, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK); else startForeground(42, n); } catch (Exception e) {}
        }
        if (wl == null) { PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE); wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "qs:alert"); wl.setReferenceCounted(false); }
        wl.acquire(120000);
        if (!busy) next();
        return START_NOT_STICKY;
    }

    private void loudOn() {
        am = (AudioManager) getSystemService(AUDIO_SERVICE); if (am == null) return;
        try { if (oldVol < 0) { oldVol = am.getStreamVolume(AudioManager.STREAM_ALARM); int max = am.getStreamMaxVolume(AudioManager.STREAM_ALARM), want = Math.max(oldVol, (int) Math.ceil(max * 0.9)); am.setStreamVolume(AudioManager.STREAM_ALARM, want, 0); } } catch (Exception e) {}
        AudioAttributes aa = attrs();
        if (Build.VERSION.SDK_INT >= 26) { afr = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE).setAudioAttributes(aa).build(); am.requestAudioFocus(afr); }
        else am.requestAudioFocus(null, AudioManager.STREAM_ALARM, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE);
    }
    private void loudOff() {
        if (am == null) return;
        try { if (oldVol >= 0) am.setStreamVolume(AudioManager.STREAM_ALARM, oldVol, 0); } catch (Exception e) {}
        oldVol = -1;
        if (Build.VERSION.SDK_INT >= 26 && afr != null) am.abandonAudioFocusRequest(afr); else am.abandonAudioFocus(null);
    }
    private static AudioAttributes attrs() { return new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build(); }

    private int[] cur; private int pos;
    private void next() {
        if (cur == null || pos >= cur.length) { synchronized (Q) { cur = Q.poll(); } pos = 0;
            if (cur == null) { busy = false; loudOff(); h.postDelayed(() -> { if (!busy) { if (wl != null && wl.isHeld()) wl.release(); stopForeground(true); stopSelf(); } }, 1500); return; }
            if (!busy) { loudOn(); startedAt = System.currentTimeMillis(); } busy = true;
            if (pos == 0 && cur != null) { /* small gap between two alerts */ final int[] c0 = cur; h.postDelayed(this::playPart, 350); return; } }
        playPart();
    }
    private void playPart() {
        if (cur == null || pos >= cur.length) { next(); return; }
        int res = cur[pos++];
        try {
            if (mp != null) { mp.release(); mp = null; }
            mp = new MediaPlayer(); mp.setAudioAttributes(attrs());
            android.content.res.AssetFileDescriptor fd = getResources().openRawResourceFd(res);
            mp.setDataSource(fd.getFileDescriptor(), fd.getStartOffset(), fd.getLength()); fd.close();
            mp.setVolume(1f, 1f);
            mp.setOnCompletionListener(p -> h.postDelayed(this::playPart, 120));
            mp.setOnErrorListener((p, a, b) -> { h.post(this::playPart); return true; });
            mp.prepare(); mp.start();
        } catch (Exception e) { h.post(this::playPart); }
    }
    @Override public void onDestroy() { if (scr != null) { try { unregisterReceiver(scr); } catch (Exception e) {} scr = null; } if (mp != null) { mp.release(); mp = null; } loudOff(); if (wl != null && wl.isHeld()) wl.release(); super.onDestroy(); }
    @Override public void onTaskRemoved(Intent root) { /* app swiped from recents: keep speaking the queued alerts */ }
    @Override public IBinder onBind(Intent i) { return null; }
}
