package info.quranicscience.app;
final class BuildConfigLite { static final String VERSION = "1.0"; }
