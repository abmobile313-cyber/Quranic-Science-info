package info.quranicscience.app;

import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;

/* Starts Firebase (for free app alerts) and creates the alert channels. */
public class QSApp extends Application {
    @Override public void onCreate() {
        super.onCreate();
        try {
            if (FirebaseApp.getApps(this).isEmpty()) FirebaseApp.initializeApp(this, new FirebaseOptions.Builder()
                .setApplicationId("1:573259128290:android:c3941a4a87d3f11e54edbb")
                .setApiKey("AIzaSyCCoqjw2BzgWcal6OVBqONYOB7x--WP12g")
                .setProjectId("quranicscience-682ff")
                .setGcmSenderId("573259128290").build());
        } catch (Exception e) {}
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) {
                NotificationChannel a = new NotificationChannel("alerts", "Fees, certificates & class updates", NotificationManager.IMPORTANCE_HIGH);
                nm.createNotificationChannel(a);
                NotificationChannel c = new NotificationChannel("classes", "Class alerts", NotificationManager.IMPORTANCE_HIGH);
                nm.createNotificationChannel(c);
            }
        }
    }
}
