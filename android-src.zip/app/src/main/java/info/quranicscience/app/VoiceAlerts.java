package info.quranicscience.app;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.ContentResolver;
import android.content.Context;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;

/* Voice alerts: every important alert has its own Android channel whose sound is a short recorded Urdu voice
   (so the phone speaks it even when the app is closed). */
final class VoiceAlerts {
    static final String[][] CH = {
        {"v_class", "Class reminders (voice)"}, {"v_pay", "Fee received (voice)"}, {"v_cert", "Certificate ready (voice)"},
        {"v_hw", "Homework checked (voice)"}, {"v_hwdue", "Homework due today (voice)"}, {"v_doubt", "Teacher answered (voice)"},
        {"v_tclass", "Teacher: class in 1 hour (voice)"}, {"v_newdoubt", "Teacher: new question (voice)"}, {"v_general", "Quranic Science news (voice)"}
    };
    static int raw(String id) {
        switch (id) {
            case "v_class": return R.raw.v_class; case "v_pay": return R.raw.v_pay; case "v_cert": return R.raw.v_cert;
            case "v_hw": return R.raw.v_hw; case "v_hwdue": return R.raw.v_hwdue; case "v_doubt": return R.raw.v_doubt;
            case "v_tclass": return R.raw.v_tclass; case "v_newdoubt": return R.raw.v_newdoubt; default: return R.raw.v_general;
        }
    }
    static boolean known(String id) { if (id == null) return false; for (String[] c : CH) if (c[0].equals(id)) return true; return false; }
    static String fromTag(String t) {
        t = t == null ? "" : t;
        if (t.startsWith("tclass-")) return "v_tclass"; if (t.startsWith("class-")) return "v_class"; if (t.startsWith("pay")) return "v_pay";
        if (t.startsWith("cert")) return "v_cert"; if (t.startsWith("hwdue-")) return "v_hwdue"; if (t.startsWith("hw-")) return "v_hw";
        if (t.startsWith("tdoubt-")) return "v_newdoubt"; if (t.startsWith("doubt-")) return "v_doubt"; return "v_general";
    }
    static void create(Context ctx) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = ctx.getSystemService(NotificationManager.class); if (nm == null) return;
        AudioAttributes aa = new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build();
        for (String[] c : CH) {
            if (nm.getNotificationChannel(c[0]) != null) continue;
            NotificationChannel ch = new NotificationChannel(c[0], c[1], NotificationManager.IMPORTANCE_HIGH);
            ch.setSound(Uri.parse(ContentResolver.SCHEME_ANDROID_RESOURCE + "://" + ctx.getPackageName() + "/" + raw(c[0])), aa);
            ch.enableVibration(true); ch.setVibrationPattern(new long[]{0, 180, 120, 180});
            nm.createNotificationChannel(ch);
        }
    }
}
