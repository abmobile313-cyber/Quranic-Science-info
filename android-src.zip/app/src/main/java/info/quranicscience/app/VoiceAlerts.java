package info.quranicscience.app;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.ContentResolver;
import android.content.Context;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;

/* Voice alerts: every important alert has its own Android channel whose sound is a short recorded Urdu voice
   (so the phone speaks it even when the app is closed). */
final class VoiceAlerts {
    static final String[][] CH = {
        {"v_class", "Class reminders (voice)"}, {"v_pay", "Fee received (voice)"}, {"v_cert", "Certificate ready (voice)"},
        {"v_hw", "Homework checked (voice)"}, {"v_hwdue", "Homework due today (voice)"}, {"v_doubt", "Teacher answered (voice)"},
        {"v_tclass", "Teacher: class in 1 hour (voice)"}, {"v_newdoubt", "Teacher: new question (voice)"}, {"v_open", "Classes open (voice)"}, {"v_pdf", "PDF ready (voice)"}, {"v_enrol", "Teacher: new student (voice)"}, {"v_newhw", "Teacher: new homework (voice)"}, {"v_live", "Class starting now (voice)"}, {"v_rec", "Class recording ready (voice)"}, {"v_change", "Class time changed (voice)"}, {"v_general", "Quranic Science news (voice)"}
    };
    static int raw(String id) {
        switch (id) {
            case "v_class": return R.raw.v_class; case "v_pay": return R.raw.v_pay; case "v_cert": return R.raw.v_cert;
            case "v_hw": return R.raw.v_hw; case "v_hwdue": return R.raw.v_hwdue; case "v_doubt": return R.raw.v_doubt;
            case "v_tclass": return R.raw.v_tclass; case "v_open": return R.raw.v_open; case "v_pdf": return R.raw.v_pdf; case "v_enrol": return R.raw.v_enrol; case "v_newhw": return R.raw.v_newhw; case "v_live": return R.raw.v_live; case "v_rec": return R.raw.v_rec; case "v_change": return R.raw.v_change; case "v_newdoubt": return R.raw.v_newdoubt; default: return R.raw.v_general;
        }
    }
    static boolean known(String id) { if (id == null) return false; for (String[] c : CH) if (c[0].equals(id)) return true; return false; }
    static String fromTag(String t) {
        t = t == null ? "" : t;
        if (t.startsWith("tclass-")) return "v_tclass"; if (t.startsWith("open-")) return "v_open"; if (t.startsWith("pdf")) return "v_pdf"; if (t.startsWith("tenrol-")) return "v_enrol"; if (t.startsWith("thw-")) return "v_newhw"; if (t.startsWith("live-")) return "v_live"; if (t.startsWith("rec-")) return "v_rec"; if (t.startsWith("change-")) return "v_change"; if (t.startsWith("class-")) return "v_class"; if (t.startsWith("pay")) return "v_pay";
        if (t.startsWith("cert")) return "v_cert"; if (t.startsWith("hwdue-")) return "v_hwdue"; if (t.startsWith("hw-")) return "v_hw";
        if (t.startsWith("tdoubt-")) return "v_newdoubt"; if (t.startsWith("doubt-")) return "v_doubt"; return "v_general";
    }
    /* 1.2.0: alerts show on one silent high-priority channel; the app itself speaks them loudly (AlertService) */
    static final String CH_ALERT = "qs_alert_loud";
    static void createAlert(Context ctx) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = ctx.getSystemService(NotificationManager.class); if (nm == null || nm.getNotificationChannel(CH_ALERT) != null) return;
        NotificationChannel ch = new NotificationChannel(CH_ALERT, "Class & course alerts (spoken by the app)", NotificationManager.IMPORTANCE_HIGH);
        ch.setSound(null, null); ch.enableVibration(true); ch.setVibrationPattern(new long[]{0, 400, 200, 400, 200, 400}); ch.setBypassDnd(false);
        ch.setLockscreenVisibility(android.app.Notification.VISIBILITY_PUBLIC); nm.createNotificationChannel(ch);
    }
    static void create(Context ctx) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = ctx.getSystemService(NotificationManager.class); if (nm == null) return;
        AudioAttributes aa = new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build();
        for (String[] c : CH) {
            if (nm.getNotificationChannel(c[0]) != null) continue;
            NotificationChannel ch = new NotificationChannel(c[0], c[1], NotificationManager.IMPORTANCE_HIGH);
            ch.setSound(Uri.parse(ContentResolver.SCHEME_ANDROID_RESOURCE + "://" + ctx.getPackageName() + "/" + raw(c[0])), aa);
            ch.enableVibration(true); ch.setVibrationPattern(new long[]{0, 180, 120, 180});
            nm.createNotificationChannel(ch);
        }
    }
}
