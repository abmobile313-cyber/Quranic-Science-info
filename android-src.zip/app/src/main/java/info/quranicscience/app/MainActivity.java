package info.quranicscience.app;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.provider.MediaStore;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.util.Base64;
import android.view.View;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.os.CancellationSignal;
import androidx.credentials.Credential;
import androidx.credentials.CredentialManager;
import androidx.credentials.CredentialManagerCallback;
import androidx.credentials.CustomCredential;
import androidx.credentials.GetCredentialRequest;
import androidx.credentials.GetCredentialResponse;
import androidx.credentials.exceptions.GetCredentialException;
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption;
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Locale;

/* Quranic Science app: the live website in an app shell, with native voice (speech-to-text and male text-to-speech),
   downloads, location for prayer times, file picker for photo/signature, and external apps for WhatsApp, Zoom and payments. */
public class MainActivity extends Activity {
    static final String HOME = "https://quranicscience.info/?app=1";
    static final String HOST = "quranicscience.info";
    static final int RQ_FILE = 11, RQ_MIC = 12, RQ_LOC = 13, RQ_NOTIF = 14;
    static final String WEB_CLIENT_ID = "573259128290-u10ehmfniqu7q5mf9jbmbvm5p13ff0pf.apps.googleusercontent.com";

    WebView web;
    ValueCallback<Uri[]> fileCb;
    GeolocationPermissions.Callback geoCb; String geoOrigin;
    SpeechRecognizer stt; String sttLang = "en-IN";
    TextToSpeech tts; boolean ttsReady = false;
    final Handler ui = new Handler(Looper.getMainLooper());
    long lastBack = 0; boolean shown = false;
    volatile boolean trusted = false; /* the phone features (voice, files, alerts) answer only our own website */

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        web = new WebView(this);
        web.setBackgroundColor(Color.TRANSPARENT);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setGeolocationEnabled(true);
        s.setAllowFileAccess(false);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setTextZoom(100);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        if (Build.VERSION.SDK_INT >= 26) s.setSafeBrowsingEnabled(true);
        s.setAllowContentAccess(false);
        s.setUserAgentString(s.getUserAgentString() + " QSApp/" + BuildConfigLite.VERSION + " (Android)");
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);

        web.addJavascriptInterface(new Bridge(), "QSNative");
        web.setWebViewClient(new Client());
        web.setWebChromeClient(new Chrome());

        tts = new TextToSpeech(this, st -> { ttsReady = st == TextToSpeech.SUCCESS; });
        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override public void onStart(String id) {}
            @Override public void onDone(String id) { if (id != null && id.startsWith("last")) js("window.qsNativeTTSDone&&qsNativeTTSDone()"); }
            @Override public void onError(String id) {}
        });

        Uri data = getIntent() != null ? getIntent().getData() : null;
        if (data == null && getIntent() != null && getIntent().getStringExtra("url") != null) data = Uri.parse(getIntent().getStringExtra("url"));
        if (b != null) web.restoreState(b);
        else web.loadUrl(data != null && HOST.equals(data.getHost()) ? withApp(data.toString()) : HOME);
    }

    static String withApp(String u) { return u.contains("app=1") ? u : u + (u.contains("?") ? "&" : "?") + "app=1"; }

    @Override protected void onNewIntent(Intent i) { super.onNewIntent(i); Uri d = i.getData(); if (d == null && i.getStringExtra("url") != null) d = Uri.parse(i.getStringExtra("url")); if (d != null && d.getHost() != null && d.getHost().endsWith(HOST)) web.loadUrl(withApp(d.toString())); }
    @Override protected void onSaveInstanceState(Bundle o) { super.onSaveInstanceState(o); web.saveState(o); }
    @Override protected void onPause() { super.onPause(); web.onPause(); }
    @Override protected void onResume() { super.onResume(); web.onResume(); }
    @Override protected void onDestroy() { if (stt != null) stt.destroy(); if (tts != null) tts.shutdown(); web.destroy(); super.onDestroy(); }

    void js(final String code) { ui.post(() -> web.evaluateJavascript(code, null)); }
    static String q(String s) { return JSONObject.quote(s == null ? "" : s); }

    boolean online() { try { ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE); NetworkInfo n = cm.getActiveNetworkInfo(); return n != null && n.isConnected(); } catch (Exception e) { return true; } }

    boolean openOutside(Uri u) {
        try {
            String sc = u.getScheme() == null ? "" : u.getScheme();
            if (sc.equals("intent")) { Intent i = Intent.parseUri(u.toString(), Intent.URI_INTENT_SCHEME); try { startActivity(i); } catch (ActivityNotFoundException e) { String f = i.getStringExtra("browser_fallback_url"); if (f != null) startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(f))); } return true; }
            startActivity(new Intent(Intent.ACTION_VIEW, u));
        } catch (Exception e) { Toast.makeText(this, "No app found to open this link", Toast.LENGTH_SHORT).show(); }
        return true;
    }

    static boolean isOurs(String url) { try { Uri u = Uri.parse(url); String h = u.getHost() == null ? "" : u.getHost(); return "https".equals(u.getScheme()) && (h.equals(HOST) || h.endsWith("." + HOST)) || (url != null && url.startsWith("file:///android_asset/")); } catch (Exception e) { return false; } }
    static boolean inside(Uri u) {
        String h = u.getHost() == null ? "" : u.getHost();
        return h.equals(HOST) || h.endsWith("." + HOST) || h.endsWith("quranicscience-682ff.firebaseapp.com");
    }

    class Client extends WebViewClient {
        @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
            Uri u = r.getUrl(); String sc = u.getScheme() == null ? "" : u.getScheme();
            if ((sc.equals("https") || sc.equals("http")) && inside(u)) return false;
            return openOutside(u);
        }
        @Override public void onPageStarted(WebView v, String url, android.graphics.Bitmap f) { trusted = isOurs(url); }
        @Override public void doUpdateVisitedHistory(WebView v, String url, boolean reload) { trusted = isOurs(url); }
        @Override public void onPageCommitVisible(WebView v, String url) {
            if (!shown) { shown = true; getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.parseColor("#04090D"))); }
        }
        @Override public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
            if (r.isForMainFrame() && !online()) v.loadUrl("file:///android_asset/offline.html");
        }
    }

    class Chrome extends WebChromeClient {
        @Override public boolean onCreateWindow(WebView v, boolean dialog, boolean user, Message msg) {
            WebView tmp = new WebView(MainActivity.this);
            tmp.setWebViewClient(new WebViewClient() {
                @Override public boolean shouldOverrideUrlLoading(WebView w, WebResourceRequest r) { Uri u = r.getUrl(); if (inside(u)) web.loadUrl(u.toString()); else openOutside(u); w.destroy(); return true; }
            });
            ((WebView.WebViewTransport) msg.obj).setWebView(tmp); msg.sendToTarget(); return true;
        }
        @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb) {
            if (has(Manifest.permission.ACCESS_FINE_LOCATION) || has(Manifest.permission.ACCESS_COARSE_LOCATION)) { cb.invoke(origin, true, false); return; }
            geoCb = cb; geoOrigin = origin; requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, RQ_LOC);
        }
        @Override public void onPermissionRequest(final PermissionRequest req) { ui.post(() -> { if (has(Manifest.permission.RECORD_AUDIO)) req.grant(req.getResources()); else req.deny(); }); }
        @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
            if (fileCb != null) fileCb.onReceiveValue(null); fileCb = cb;
            try { startActivityForResult(p.createIntent(), RQ_FILE); } catch (Exception e) { fileCb = null; return false; }
            return true;
        }
    }

    boolean has(String p) { return checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED; }

    @Override protected void onActivityResult(int rq, int rc, Intent d) {
        super.onActivityResult(rq, rc, d);
        if (rq == RQ_FILE && fileCb != null) { fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(rc, d)); fileCb = null; }
    }

    @Override public void onRequestPermissionsResult(int rq, String[] p, int[] g) {
        super.onRequestPermissionsResult(rq, p, g);
        boolean ok = g.length > 0 && g[0] == PackageManager.PERMISSION_GRANTED;
        if (rq == RQ_LOC && geoCb != null) { geoCb.invoke(geoOrigin, ok, false); geoCb = null; }
        if (rq == RQ_MIC) { if (ok) startListen(); else js("window.qsNativeSTT&&qsNativeSTT('error','permission')"); }
    }

    /* ---------- voice: speech to text ---------- */
    void startListen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { js("window.qsNativeSTT&&qsNativeSTT('error','unavailable')"); return; }
        if (stt == null) {
            stt = SpeechRecognizer.createSpeechRecognizer(this);
            stt.setRecognitionListener(new RecognitionListener() {
                public void onReadyForSpeech(Bundle p) { js("window.qsNativeSTT&&qsNativeSTT('ready','')"); }
                public void onBeginningOfSpeech() {}
                public void onRmsChanged(float v) {}
                public void onBufferReceived(byte[] b) {}
                public void onEndOfSpeech() { js("window.qsNativeSTT&&qsNativeSTT('end','')"); }
                public void onError(int e) { js("window.qsNativeSTT&&qsNativeSTT('error'," + q(String.valueOf(e)) + ")"); }
                public void onResults(Bundle r) { ArrayList<String> a = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION); js("window.qsNativeSTT&&qsNativeSTT('final'," + q(a != null && !a.isEmpty() ? a.get(0) : "") + ")"); }
                public void onPartialResults(Bundle r) { ArrayList<String> a = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION); if (a != null && !a.isEmpty()) js("window.qsNativeSTT&&qsNativeSTT('partial'," + q(a.get(0)) + ")"); }
                public void onEvent(int t, Bundle p) {}
            });
        }
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, sttLang);
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        stt.startListening(i);
    }

    /* ---------- voice: text to speech, male voice when the phone has one ---------- */
    static final String[] MALE = {"-iol", "-iom", "-gbd", "-gbb", "-rjs", "-end", "-ene", "-hid", "-hie", "-ard", "-are", "-arz", "male", "#male"};
    Voice pickVoice(Locale want) {
        Voice best = null, any = null;
        try {
            for (Voice v : tts.getVoices()) {
                Locale l = v.getLocale(); if (l == null || !l.getLanguage().equals(want.getLanguage())) continue;
                if (v.isNetworkConnectionRequired() && !online()) continue;
                String n = v.getName().toLowerCase(Locale.ROOT);
                if (n.contains("female")) { if (any == null) any = v; continue; }
                for (String m : MALE) if (n.contains(m)) { if (best == null || (!l.getCountry().isEmpty() && l.getCountry().equals(want.getCountry()))) best = v; break; }
                if (any == null) any = v;
            }
        } catch (Exception e) {}
        return best != null ? best : any;
    }

    class Bridge {
        @JavascriptInterface public String version() { if (!trusted) return "";  return BuildConfigLite.VERSION; }
        @JavascriptInterface public void listen(final String lang) { if (!trusted) return; 
            ui.post(() -> { sttLang = lang == null || lang.isEmpty() ? "en-IN" : lang; if (tts != null) tts.stop();
                if (has(Manifest.permission.RECORD_AUDIO)) startListen(); else requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, RQ_MIC); });
        }
        @JavascriptInterface public void stopListen() { if (!trusted) return;  ui.post(() -> { if (stt != null) stt.cancel(); }); }
        @JavascriptInterface public boolean speak(final String text, final String lang) { if (!trusted) return false; 
            if (!ttsReady) return false;
            ui.post(() -> {
                Locale loc = Locale.forLanguageTag(lang == null || lang.isEmpty() ? "en-IN" : lang);
                if (tts.isLanguageAvailable(loc) < TextToSpeech.LANG_AVAILABLE && loc.getLanguage().equals("ur")) loc = Locale.forLanguageTag("hi-IN");
                tts.setLanguage(loc);
                Voice v = pickVoice(loc); boolean male = false;
                if (v != null) { tts.setVoice(v); String n = v.getName().toLowerCase(Locale.ROOT); for (String m : MALE) if (n.contains(m) && !n.contains("female")) { male = true; break; } }
                tts.setPitch(male ? 0.95f : 0.62f); tts.setSpeechRate(0.95f);
                String[] parts = text.split("(?<=[.!?۔؟\n])");
                tts.stop();
                for (int k = 0; k < parts.length; k++) {
                    String t = parts[k].trim(); if (t.isEmpty() && k < parts.length - 1) continue;
                    tts.speak(t, TextToSpeech.QUEUE_ADD, null, (k == parts.length - 1 ? "last" : "p") + k);
                }
            });
            return true;
        }
        @JavascriptInterface public void stopSpeak() { if (!trusted) return;  ui.post(() -> { if (tts != null) tts.stop(); }); }
        @JavascriptInterface public void saveFile(final String name, final String mime, final String b64) { if (!trusted) return; 
            ui.post(() -> {
                try {
                    byte[] bytes = Base64.decode(b64, Base64.DEFAULT);
                    if (Build.VERSION.SDK_INT >= 29) {
                        ContentValues cv = new ContentValues();
                        cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                        cv.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                        cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Quranic Science");
                        Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                        try (OutputStream o = getContentResolver().openOutputStream(u)) { o.write(bytes); }
                    } else {
                        File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS); if (dir != null) dir.mkdirs();
                        try (FileOutputStream o = new FileOutputStream(new File(dir, name))) { o.write(bytes); }
                    }
                    Toast.makeText(MainActivity.this, "Saved in Downloads: " + name, Toast.LENGTH_LONG).show();
                } catch (Exception e) { Toast.makeText(MainActivity.this, "Could not save the file", Toast.LENGTH_SHORT).show(); }
            });
        }
        @JavascriptInterface public void share(final String text) { if (!trusted) return; 
            ui.post(() -> { Intent i = new Intent(Intent.ACTION_SEND); i.setType("text/plain"); i.putExtra(Intent.EXTRA_TEXT, text); startActivity(Intent.createChooser(i, "Share")); });
        }
        @JavascriptInterface public void openExternal(final String url) { if (!trusted) return;  ui.post(() -> openOutside(Uri.parse(url))); }
        @JavascriptInterface public void requestPushToken() { if (!trusted) return; 
            ui.post(() -> {
                if (Build.VERSION.SDK_INT >= 33 && !has(Manifest.permission.POST_NOTIFICATIONS)) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, RQ_NOTIF);
                try { com.google.firebase.messaging.FirebaseMessaging.getInstance().getToken().addOnCompleteListener(t -> {
                    if (t.isSuccessful() && t.getResult() != null) js("window.qsNativeFcm&&qsNativeFcm(" + q(t.getResult()) + ")");
                    else js("window.qsNativeFcm&&qsNativeFcm('')"); }); } catch (Exception e) { js("window.qsNativeFcm&&qsNativeFcm('')"); }
            });
        }
        @JavascriptInterface public void googleSignIn() { if (!trusted) return;  ui.post(MainActivity.this::startGoogle); }
        @JavascriptInterface public void scheduleReminders(final String json) { if (!trusted) return; 
            ui.post(() -> {
                try {
                    if (Build.VERSION.SDK_INT >= 33 && !has(Manifest.permission.POST_NOTIFICATIONS)) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, RQ_NOTIF);
                    AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
                    JSONArray a = new JSONArray(json); long now = System.currentTimeMillis(); int n = 0;
                    for (int k = 0; k < a.length(); k++) {
                        JSONObject o = a.getJSONObject(k); long at = o.optLong("at") - 3600000L; if (at <= now) continue;
                        String id = o.optString("id"); int code = id.hashCode();
                        Intent i = new Intent(MainActivity.this, ReminderReceiver.class); i.putExtra("title", o.optString("title")); i.putExtra("nid", code);
                        PendingIntent pi = PendingIntent.getBroadcast(MainActivity.this, code, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
                        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi); n++;
                    }
                    js("window.qsNativeReminders&&qsNativeReminders(" + n + ")");
                } catch (Exception e) {}
            });
        }
        @JavascriptInterface public void setBars(final boolean light) {
            if (!trusted) return;
            ui.post(() -> { int c = light ? Color.parseColor("#F4F1EA") : Color.parseColor("#04090D"); getWindow().setStatusBarColor(c); getWindow().setNavigationBarColor(c);
                int f = getWindow().getDecorView().getSystemUiVisibility(); if (light) f |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR; else f &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                if (Build.VERSION.SDK_INT >= 26) { if (light) f |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR; else f &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR; }
                getWindow().getDecorView().setSystemUiVisibility(f); });
        }
        @JavascriptInterface public void exitApp() { if (!trusted) return;  ui.post(MainActivity.this::finish); }
    }

    /* ---------- Google login (native Google account picker, then the website signs in to Firebase with the token) ---------- */
    void startGoogle() {
        try {
            CredentialManager cm = CredentialManager.create(this);
            GetSignInWithGoogleOption opt = new GetSignInWithGoogleOption.Builder(WEB_CLIENT_ID).build();
            GetCredentialRequest req = new GetCredentialRequest.Builder().addCredentialOption(opt).build();
            cm.getCredentialAsync(this, req, new CancellationSignal(), (java.util.concurrent.Executor) ui::post, new CredentialManagerCallback<GetCredentialResponse, GetCredentialException>() {
                @Override public void onResult(GetCredentialResponse r) {
                    Credential c = r.getCredential();
                    if (c instanceof CustomCredential && GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL.equals(c.getType())) {
                        GoogleIdTokenCredential g = GoogleIdTokenCredential.createFrom(c.getData());
                        js("window.qsNativeGoogle&&qsNativeGoogle('ok'," + q(g.getIdToken()) + ")");
                    } else js("window.qsNativeGoogle&&qsNativeGoogle('error','type')");
                }
                @Override public void onError(GetCredentialException e) { js("window.qsNativeGoogle&&qsNativeGoogle('error'," + q(e.getClass().getSimpleName() + ": " + e.getMessage()) + ")"); }
            });
        } catch (Exception e) { js("window.qsNativeGoogle&&qsNativeGoogle('error'," + q(e.toString()) + ")"); }
    }

    @Override public void onBackPressed() {
        web.evaluateJavascript("(function(){try{return window.qsAppBack?String(qsAppBack()):'false'}catch(e){return 'false'}})()", r -> {
            if ("\"true\"".equals(r)) return;
            if (web.canGoBack()) { web.goBack(); return; }
            long now = System.currentTimeMillis();
            if (now - lastBack < 2000) finish(); else { lastBack = now; Toast.makeText(this, "Press back again to exit", Toast.LENGTH_SHORT).show(); }
        });
    }
}
